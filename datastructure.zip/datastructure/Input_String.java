package datastructure;
import java.util.*;

public class Input_String {
		public static void main(String[] args){
		    Scanner s = new Scanner(System.in);
		    String[] array = new String[20];

		    System.out.println("Please enter the any string:\n");

		    for (int i = 0; i < 20; i++) 
		    {
		        array[i] = s.nextLine();
		        
		    } 
		    
		        System.out.println(array[0]);
		        
		    


		   
		}

	}



package datastructure;
import java.util.*;
import java.util.Scanner;

public class Matrixtd {
	public static void main(String[] args) {
		int aa[][]=new int [4][4];
		Scanner aaa=new Scanner(System.in);
		System.out.println("enter the number:");
		for(int i=0;i<4;i++)
		{
			for(int j=0;j<4;j++) 
			{
				aa[i][j]= aaa.nextInt();
			}
		}
		
		System.out.println("your entered values is:");
		for(int i=0;i<4;i++)
		{
			for(int j=0;j<4;j++) 
			{
				System.out.print(aa[i][j] + " ");
			}
			
			System.out.println(); 
		}
		
		
	}

}

package datastructure;
import java.util.*;


public class Bitmanipulation {
	
	 public static boolean PowerOfTwo(int x)
	    {
	        //if(x % 2 != 0)
	          //return false ;
	        //else
	        //{
	            while(x % 2 == 0) 
	            	x /= 2;
	            
	            return ( x == 1 );
	            	            
	        //}
	            
	    }
        public static void main(String[] args) {
		
		Scanner aa=new Scanner(System.in);
		System.out.println("enter the values of x");
		int x=aa.nextInt();
		
		System.out.println("x " + (PowerOfTwo(x) ? "is" : "is not") + " power of 2" );    
	        
	}

}

package datastructure;
import java.io.IOException;
import java.io.PrintWriter;

public class Createfile {

	public static void main(String[] args) throws IOException
	{
		PrintWriter outputFile=new PrintWriter("RanjitFile.txt");
		outputFile.println("this is my document");
		outputFile.println("this is my Second document");
		outputFile.println("this is my Third document");
		outputFile.close();
		}

}

package datastructure;
import javax.swing.*;

public class Joption {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name;
		String Surname;
		name=JOptionPane.showInputDialog("please inter your name: ");

	}

}

package datastructure;
import java.util.*;

public class GCD
   {
      public static void main(String args[])
        {
    	   int hcf=0;
           int n1;
           int n2;
           Scanner aa=new Scanner(System.in);
           System.out.println("enter any two number: ");
           n1=aa.nextInt();
           n2=aa.nextInt();

 

      for(int i = 1; i <= n1 || i <= n2; i++) 
       {
           if( n1%i == 0 && n2%i == 0 )
       	   hcf = i;
       }

        System.out.println("HCF of given two numbers is " +hcf);
        int lcm = (n1*n2)/hcf;
        System.out.println("LCM of given two numbers is " +lcm);

         }

     }



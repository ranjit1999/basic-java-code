package datastructure;

public class Store_innewArray {
	public static void Change(int x[])
	{
	   for(int i=0;i<x.length;i++)
	   {
		   x[i]+=-5;
	   }
	
	}

	public static void main(String[] args) {
		int a[]= {5,9,4,23,456};
		Change(a);
		for(int y: a)
		System.out.print(y+" ");
			
		
	}

}

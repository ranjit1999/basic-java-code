package datastructure;

public class ArrayMethod {
	public static void Display(int x[] [])
	{
		for(int i=0;i<x.length;i++)
		{
			for(int j=0;j<x[i].length;j++)
			{
				System.out.print(x[i][j]+"\t");    
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		int a[] []= {{3,4,56,78,23},{8,45,3,456,6}};
		int b[] []= {{13,4,156,78,123},{8,45,6},{22,45}};
		System.out.println("enter the first array");
		Display(a);
		System.out.println("enter the second array");
		Display(b);
		
		
		
		
		}

}

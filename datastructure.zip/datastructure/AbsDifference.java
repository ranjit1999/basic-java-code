package datastructure;
import java.util.*;

public class AbsDifference {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner aa=new Scanner(System.in);
		System.out.println("enter first number: \n");
		int n=aa.nextInt();
		System.out.println("enter second number: \n");
		int m=aa.nextInt();
		//int c=aa.nextInt();
		 int c=(n-m);
		
		//System.out.println(Math.abs(n-m));
		System.out.println(c);
	}

}

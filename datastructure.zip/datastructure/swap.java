package datastructure;
import java.util.*;

public class swap {
	public static void swap_no(int x, int y)
	{
		int t;
		t=x;
		x=y;
		y=t;
	}

	public static void main(String[] args) {
		
		Scanner aa=new Scanner(System.in);
		int t=aa.nextInt();
		
		System.out.println("enter the first number");
		int x=aa.nextInt();
		
		System.out.println("enter the second number");
		int y=aa.nextInt();
		
		System.out.println("swaping no is"+ swap_no(x,y));
		

	}

}
